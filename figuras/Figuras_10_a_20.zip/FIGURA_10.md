![Figura 10. Interfaz de la aplicación para configurar la dimensión de la matriz y el rango de aproximación.](figura_10_configuracion_matriz_rango.png)

*Figura 10. Interfaz de la aplicación para configurar la dimensión de la matriz y el rango de aproximación.*

C++/Qt; n = 100, k = 7.
